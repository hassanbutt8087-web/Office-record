# Office Record (Android)

Bilingual Urdu/English Android starter app for recording:
- Leave days
- Extra duty (start/end time)
- Meetings (start/end time and details)
- Optional authority/order note
- Summary counts, CSV sharing, and monthly PDF report sharing

## Build an APK
1. Install Android Studio on a computer.
2. Open this `OfficeRecord` folder in Android Studio.
3. Allow Gradle sync (requires internet the first time).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location.

Records are stored locally on the phone in an SQLite database. Uninstalling the app or clearing its data can erase them. Export/share CSV regularly for backup.

This is a starter project source, not a precompiled APK. Monthly PDF reports are generated for the month entered in the date field and can be shared from the Android share sheet. The app uses a simple date field (`YYYY-MM-DD`) and 24-hour time fields.

## Build APK using only a phone (GitHub Actions)
1. Create a free GitHub account and sign in in your phone browser.
2. Create a new repository and upload the contents of this project (including the hidden `.github` folder).
3. Open the repository's **Actions** tab and enable workflows if asked.
4. Run **Build Android APK** using **Run workflow** (or push to `main`).
5. When the run completes, open it and download the `OfficeRecord-debug-apk` artifact. GitHub may ask you to sign in to download it.

This cloud build uses GitHub Actions. The generated debug APK is for testing/personal installation, not a Play Store release.
