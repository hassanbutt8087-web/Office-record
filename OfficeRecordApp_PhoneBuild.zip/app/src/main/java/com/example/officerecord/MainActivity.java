package com.example.officerecord;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.net.Uri;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    SQLiteDatabase db;
    LinearLayout root, list;
    EditText date, start, end, detail, authority;
    Spinner type;
    TextView summary;
    boolean urdu = true;

    String t(String u, String e) { return urdu ? u : e; }
    int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density); }

    public void onCreate(Bundle b) {
        super.onCreate(b);
        db = openOrCreateDatabase("office_records.db", MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, date TEXT, start TEXT, end TEXT, detail TEXT, authority TEXT)");
        build();
    }

    TextView text(String s, int size) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(size);
        v.setTextColor(0xff172033); v.setPadding(0,dp(6),0,dp(6)); return v;
    }
    EditText field(String hint) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextSize(15);
        e.setHint(hint); e.setPadding(dp(10),dp(8),dp(10),dp(8));
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff64748b));
        return e;
    }
    void add(LinearLayout box, View v) {
        box.addView(v, new LinearLayout.LayoutParams(-1, -2));
    }
    void build() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(18),dp(18),dp(18),dp(24));
        root.setBackgroundColor(0xfff4f7fb); scroll.addView(root); setContentView(scroll);

        LinearLayout header = new LinearLayout(this); header.setOrientation(0);
        TextView title = text(t("آفس ریکارڈ","Office Record"),24); title.setTypeface(null,Typeface.BOLD);
        header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        Button lang = new Button(this); lang.setText(urdu ? "English" : "اردو");
        lang.setOnClickListener(v->{urdu=!urdu; build();}); header.addView(lang); add(root,header);

        summary = text("",15); summary.setPadding(0,dp(8),0,dp(12)); add(root,summary);
        add(root,text(t("نیا ریکارڈ شامل کریں","Add New Record"),19));
        type = new Spinner(this);
        String[] choices = urdu ? new String[]{"چھٹی","اضافی ڈیوٹی","اجلاس"} : new String[]{"Leave","Extra Duty","Meeting"};
        type.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, choices)); add(root,type);

        date=field(t("تاریخ (YYYY-MM-DD)","Date (YYYY-MM-DD)")); date.setText(new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date())); add(root,date);
        start=field(t("شروع ہونے کا وقت (مثلاً 09:00)","Start time (e.g. 09:00)")); add(root,start);
        end=field(t("ختم ہونے کا وقت (مثلاً 17:00)","End time (e.g. 17:00)")); add(root,end);
        detail=field(t("تفصیل / وجہ","Details / Reason")); add(root,detail);
        authority=field(t("افسرانِ بالا کے حکم پر (اختیاری)","By order of higher authorities (optional)")); add(root,authority);

        Button save = new Button(this); save.setText(t("ریکارڈ محفوظ کریں","Save Record"));
        save.setOnClickListener(v->save()); add(root,save);
        Button export = new Button(this); export.setText(t("CSV رپورٹ شیئر کریں","Share CSV Report"));
        export.setOnClickListener(v->shareCsv()); add(root,export);
        Button pdf = new Button(this); pdf.setText(t("ماہانہ PDF رپورٹ بنائیں","Create Monthly PDF Report"));
        pdf.setOnClickListener(v->createMonthlyPdf()); add(root,pdf);

        add(root,text(t("محفوظ شدہ ریکارڈ","Saved Records"),19));
        list = new LinearLayout(this); list.setOrientation(1); add(root,list);
        refresh();
    }
    void save() {
        String d=date.getText().toString().trim();
        if(!d.matches("\\d{4}-\\d{2}-\\d{2}")) { date.setError(t("تاریخ YYYY-MM-DD میں لکھیں","Use YYYY-MM-DD")); return; }
        String[] kinds = urdu ? new String[]{"چھٹی","اضافی ڈیوٹی","اجلاس"} : new String[]{"Leave","Extra Duty","Meeting"};
        ContentValues cv=new ContentValues(); cv.put("kind",kinds[type.getSelectedItemPosition()]);
        cv.put("date",d); cv.put("start",start.getText().toString()); cv.put("end",end.getText().toString());
        cv.put("detail",detail.getText().toString()); cv.put("authority",authority.getText().toString());
        db.insert("records",null,cv);
        Toast.makeText(this,t("ریکارڈ محفوظ ہو گیا","Record saved"),Toast.LENGTH_SHORT).show();
        start.setText(""); end.setText(""); detail.setText(""); authority.setText(""); refresh();
    }
    void refresh() {
        if(list==null) return;
        list.removeAllViews();
        Cursor c=db.rawQuery("SELECT COUNT(*), SUM(CASE WHEN kind LIKE '%چھٹی%' OR kind='Leave' THEN 1 ELSE 0 END), SUM(CASE WHEN kind LIKE '%اضافی%' OR kind='Extra Duty' THEN 1 ELSE 0 END), SUM(CASE WHEN kind LIKE '%اجلاس%' OR kind='Meeting' THEN 1 ELSE 0 END) FROM records",null);
        if(c.moveToFirst()) summary.setText(t("کل ریکارڈ: ","Total records: ")+c.getInt(0)+"   "+t("چھٹیاں: ","Leaves: ")+c.getInt(1)+"   "+t("اضافی ڈیوٹیاں: ","Extra duties: ")+c.getInt(2)+"   "+t("اجلاس: ","Meetings: ")+c.getInt(3));
        c.close();
        Cursor r=db.rawQuery("SELECT id,kind,date,start,end,detail,authority FROM records ORDER BY date DESC,id DESC",null);
        while(r.moveToNext()) {
            final int id=r.getInt(0);
            String s=r.getString(1)+" • "+r.getString(2)+"\n"+t("وقت: ","Time: ")+safe(r.getString(3))+" - "+safe(r.getString(4))+"\n"+safe(r.getString(5))+"\n"+(r.getString(6)==null||r.getString(6).isEmpty()?"":t("حکم: ","Authority: ")+r.getString(6));
            TextView item=text(s,14); item.setBackgroundColor(0xffffffff); item.setPadding(dp(12),dp(10),dp(12),dp(10));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(8); list.addView(item,p);
            Button del=new Button(this); del.setText(t("حذف کریں","Delete"));
            del.setOnClickListener(v->{db.delete("records","id=?",new String[]{String.valueOf(id)});refresh();}); list.addView(del);
        }
        r.close();
    }
    String safe(String s){ return s==null?"":s; }

    void createMonthlyPdf() {
        String month = date.getText().toString().trim();
        if (!month.matches("\\d{4}-\\d{2}.*")) {
            month = new SimpleDateFormat("yyyy-MM", Locale.US).format(new Date());
        } else {
            month = month.substring(0,7);
        }
        PdfDocument doc = new PdfDocument();
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTextSize(12);
        paint.setColor(0xff172033);
        int pageNo = 1, y = 54;
        PdfDocument.Page page = doc.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create());
        Canvas canvas = page.getCanvas();
        paint.setTextSize(20); paint.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));
        canvas.drawText("Office Record - Monthly Report", 40, 40, paint);
        paint.setTextSize(12); paint.setTypeface(Typeface.DEFAULT);
        canvas.drawText("Month: "+month, 40, y, paint); y += 28;
        String[] headings={"Type","Date","Start","End","Details","Authority"};
        int[] xs={40,145,235,310,385,500};
        paint.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));
        for(int i=0;i<headings.length;i++) canvas.drawText(headings[i],xs[i],y,paint);
        y+=18; paint.setTypeface(Typeface.DEFAULT);
        Cursor c=db.rawQuery("SELECT kind,date,start,end,detail,authority FROM records WHERE substr(date,1,7)=? ORDER BY date,id",new String[]{month});
        int count=0, leaves=0, duties=0, meetings=0;
        while(c.moveToNext()) {
            String kind=safe(c.getString(0)), dt=safe(c.getString(1));
            String st=safe(c.getString(2)), en=safe(c.getString(3));
            String details=safe(c.getString(4)), auth=safe(c.getString(5));
            if(kind.contains("چھٹی") || kind.equals("Leave")) leaves++;
            if(kind.contains("اضافی") || kind.equals("Extra Duty")) duties++;
            if(kind.contains("اجلاس") || kind.equals("Meeting")) meetings++;
            if(y>790) {
                doc.finishPage(page); pageNo++; y=45;
                page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create());
                canvas=page.getCanvas();
            }
            String[] vals={kind,dt,st,en,details,auth};
            for(int i=0;i<vals.length;i++) {
                String v=vals[i].replace('\n',' ');
                if(v.length()> (i==4||i==5?13:12)) v=v.substring(0,(i==4||i==5?12:11))+"…";
                canvas.drawText(v,xs[i],y,paint);
            }
            y+=20; count++;
        }
        c.close();
        if(count==0) canvas.drawText("No records found for this month.",40,y+10,paint);
        y+=28;
        paint.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));
        canvas.drawText("Summary: Records "+count+" | Leaves "+leaves+" | Extra duties "+duties+" | Meetings "+meetings,40,Math.min(y,810),paint);
        doc.finishPage(page);
        try {
            File outDir=new File(getCacheDir(),"reports"); outDir.mkdirs();
            File out=new File(outDir,"Office_Report_"+month+".pdf");
            FileOutputStream fos=new FileOutputStream(out); doc.writeTo(fos); fos.close(); doc.close();
            Uri uri=FileProvider.getUriForFile(this,getPackageName()+".provider",out);
            Intent send=new Intent(Intent.ACTION_SEND); send.setType("application/pdf");
            send.putExtra(Intent.EXTRA_SUBJECT,"Office Monthly Report "+month);
            send.putExtra(Intent.EXTRA_STREAM,uri); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send,t("PDF رپورٹ شیئر کریں","Share PDF report")));
        } catch(Exception e) {
            doc.close(); Toast.makeText(this,"PDF error: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
    void shareCsv() {
        StringBuilder csv=new StringBuilder("Type,Date,Start,End,Details,Authority\n");
        Cursor c=db.rawQuery("SELECT kind,date,start,end,detail,authority FROM records ORDER BY date",null);
        while(c.moveToNext()) {
            for(int i=0;i<6;i++){ if(i>0)csv.append(','); String x=safe(c.getString(i)).replace("\"","\"\"").replace("\n"," "); csv.append('"').append(x).append('"'); }
            csv.append('\n');
        } c.close();
        Intent send=new Intent(Intent.ACTION_SEND); send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT,"Office Record CSV"); send.putExtra(Intent.EXTRA_TEXT,csv.toString());
        startActivity(Intent.createChooser(send,t("رپورٹ شیئر کریں","Share report")));
    }
}